################################
# install packges              #
################################

pkg update
pkg upgrade
pkg install curl
pkg install bash
pkg install wget
sh tebasindex.sh

