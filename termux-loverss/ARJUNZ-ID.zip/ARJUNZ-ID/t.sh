
















curl -T /storage/emulated/0/$fil $ta
echo "Result: $ta"
open-termux $ta
