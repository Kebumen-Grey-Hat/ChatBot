printf "       \e[101m\e[1;77m::       AUTHOR : ARJUN-NEWBIE        ::\e[0m\n"
echo
printf "\e[101m\e[1;44m~# GUTHUB    : ARJUNZ-NEWBIE                               \e[0m\n"
printf "\e[101m\e[1;44m~# Chanel Yt : NEWBIE                                      \e[0m\n"
printf "\e[101m\e[1;44m~# THANKS TO : ALLAH SWT                                   \e[0m\n"
echo
echo
