#!/bin/bash
echo 'Installing Packges Please Wait 5 s/k'
pkg update
pip2 install colorama
pip2 install requests
pip2 install bs4
